import static processing.core.PApplet.*;
;
abstract class TimeShape {

    public static class Minutes extends TimeShape {

        protected float getStartAngle() {
            return map(minute() + second() / 60, 0, 60, PI * -.5f, PI * 1.5f);
        }
    }

    public static class Seconds extends TimeShape {

        protected float getStartAngle() {
            return map(second(), 0, 60, PI * -.5f, PI * 1.5f);
        }
    }

    public static class Millis extends TimeShape {

        protected float getStartAngle() {
            return map(System.currentTimeMillis() % 1000, 0, 1000, PI * -.5f, PI * 1.5f);
        }
    }

    float radius;

    int   steps;

    float width;

    int   mode;

    public void draw(float x, float y) {
        float startAngle = getStartAngle();
        float angleSteps = TWO_PI / steps;
        switch (mode) {
            case OrbMode.ORB:
                OrbitClock.$.fill(steps, steps);
                OrbitClock.$.noStroke();
                OrbitClock.$.ellipse(x + cos(startAngle) * radius, y + sin(startAngle) * radius, 10 * width, 10 * width);
                break;
            case OrbMode.ORBIT:
                OrbitClock.$.noFill();
                OrbitClock.$.strokeWeight(width);
                for (int i = 0; i < steps; i++) {
                    float angle = startAngle - angleSteps * i;
                    OrbitClock.$.stroke(0, map(i, 0, steps, 255, 0));
                    OrbitClock.$.arc(x, y, radius * 2, radius * 2, angle, angle + angleSteps);
                }
        }
    }

    protected abstract float getStartAngle();
}