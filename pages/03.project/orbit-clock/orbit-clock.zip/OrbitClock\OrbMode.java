/**
 * Enum
 */
class OrbMode {

    public static final int
        ORB = 0,
        ORBIT = 1;
}
